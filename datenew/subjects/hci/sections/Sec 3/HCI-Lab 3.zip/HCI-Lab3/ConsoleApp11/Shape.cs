﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Shape
    {
        public virtual double getArea()
        {
            return 0;
        }
    }
    class Rectangle : Shape
    {
        public int length { get; set; }
        public int width { get; set; }

        public Rectangle(int length, int width)
        {
            this.length = length;
            this.width = width;
        }

        public override double getArea()
        {
            return length * width;
        }
    }

    class Circle : Shape
    {
        public int radius { get; set; }
        public Circle(int radius)
        {
            this.radius = radius;
        }


        public override double getArea()
        {
            return radius*radius*Math.PI;
        }

    }
}
