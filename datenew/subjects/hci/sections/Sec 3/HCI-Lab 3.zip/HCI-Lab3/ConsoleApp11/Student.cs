﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Student
    {
        public string Name { get; set; }    
        public int Id { get; set; }
        public int[] grades = new int[3];

        // GetAverage, GetHighest,Lowest,Ispassed 

        public Student(string name, int id, int[] grades)
        {
            Name = name;
            Id = id;
            this.grades = grades;
        }
        public double getAverage()
        {
            int sum = 0;
            for(int i = 0; i < grades.Length; i++)
            {
                sum += grades[i];
            }
            return (double) sum/grades.Length;
        }

        public int GetHighest()
        {
            // 60 70 50
            int highest = grades[0];
            for(int i = 1; i < grades.Length; i++)
            {
                if(grades[i] > highest)
                    highest = grades[i];
            }
            return highest;
        }

        public int GetLowest()
        {
            // 60 70 50
            int lowest = grades[0];
            for (int i = 1; i < grades.Length; i++)
            {
                if (grades[i] < lowest)
                    lowest = grades[i];
            }
            return lowest;
        }
        public bool isPassed()
        {
            bool passed = true;
            for (int i = 0; i < grades.Length; i++)
            {
                if (grades[i] < 50)
                {
                    passed = false;
                    break;
                }
            }
            return passed;
        }

        public void printInfo()
        {
            Console.WriteLine($"{getAverage()}, {GetHighest()}, " +
                $"{GetLowest()}, {isPassed()}"); 
        }
    }
}
