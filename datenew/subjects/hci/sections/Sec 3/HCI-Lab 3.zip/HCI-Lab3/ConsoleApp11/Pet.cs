﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Pet
    {
        public string Name { get; set; }
        private int Age {  get; set; }

        public Pet() { }
        public Pet(string name, int age)
        {
            Name = name;
            Age = age;
        }

        public virtual void MakeASound()
        {
            Console.WriteLine("Animal Sound");
        }

        public int getAge()
        {
            return Age;
        }
    }

    class Cat : Pet
    {
        public string color {  get; set; }

        public Cat(string name, int age, string color)
            : base(name, age)
        {
            this.color = color;
        }
        public override void MakeASound()
        {
         
            Console.WriteLine("Meow");
        }

    }

    class Dog : Pet
    {
        
        public override void MakeASound()
        {

            Console.WriteLine("Ruff ruff");
        }

    }

}
