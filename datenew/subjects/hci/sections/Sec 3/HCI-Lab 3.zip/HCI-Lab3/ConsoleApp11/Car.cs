﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Dependency
namespace ConsoleApp11
{
    internal class Car
    {
        // Properties
        // Brand, Model, price
        public string Brand {  get; set; }
        public string Model { get; set; }
        public double Price { get; set; }
        public int[] grades = new int[3];
        // Belongs to the class itself
        public static int Count { get; set; } = 0;
        public Car()
        {
            Count++;

        }

        public Car(string Brand, string model, double price)
        {
            this.Brand = Brand;
            this.Model = model;
            this.Price = price;
            Count++;

        }

        // Copy Constructor
        public Car (Car source)
        {
            this.Brand = source.Brand;
            this.Model = source.Model;
            this.Price = source.Price;
            Count++;

        }

        // Methods
        // discount 
        public double getDiscount()
        {
            return this.Price*0.90;
        }

        public static Car copyCar(Car c)
        {
            Car car = new Car();
            car.Brand = c.Brand;
            car.Model = c.Model;
            car.Price = c.Price;
            return car;
        }
        public void printInfo()
        {
            Console.WriteLine(Count);
            Console.WriteLine($"{Brand}, {Model}, {Price}");
        }

        public void ChangeCounter()
        {
            Count = 0;
        }
    }
}
