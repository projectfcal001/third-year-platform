﻿namespace ConsoleApp11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //    Car c1 = new Car("Nissan", "Sunny", 200) { Price = 800};
            //    Car c4 = new Car(c1);

            //    c4.Brand = "jhkj";
            //    //c1.printInfo();
            //    //c4.printInfo();
            //    Console.WriteLine(c1.getDiscount());


            //    Car c2 = new Car();
            //    c2.Brand = "abc";
            //    c2.Model = "xyz";
            //    c2.Price = 100;

            //    Car c3 = new Car() {Brand = "xyz", Model="abc", Price=400 } ;
            //    //c3.ChangeCounter();
            //    c2.printInfo();
            //    //Property setting

            //int[] g = { 60, 70, 30 };
            //Student s1 = new Student("Omar", 20, 
            //    new int[] {80,70,90 }
            //    );
            //s1.printInfo();
            //    Pet p1 = new Pet();
            //    p1.MakeASound();
            //    Cat c1 = new Cat("Zeko", 2 ,"Black");
            //    c1.MakeASound();
            //    Pet p2 = new Cat("kjhn", 2, "ghj");
            //    p2.MakeASound();
            ////Polymorphism 
            //    Pet[] pets = new Pet[2];
            //    pets[0] = new Cat("Zeko", 2, "Black");
            //    pets[1] = new Dog();

            //    for (int i = 0; i < pets.Length; i++) {
            //        pets[i].MakeASound();
            //    }

            Shape[] shapes = new Shape[2];
            shapes[0] = new Rectangle(4, 5);
            shapes[1] = new Circle(7);

            foreach (Shape shape in shapes) {
                  Console.WriteLine (shape.getArea());            
            
            }
        }

    }
}
