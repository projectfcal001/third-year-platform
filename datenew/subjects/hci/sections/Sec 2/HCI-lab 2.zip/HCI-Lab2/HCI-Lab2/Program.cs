﻿namespace HCILab2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Calling methods

            int sum = Add(5, 6);
            int sum2 = Add2(5, 6);

            Console.WriteLine(sum);
            Console.WriteLine(sum2);
            Console.WriteLine(Area(4, 6));

            int x = 10;
            int y = 20;
            Console.WriteLine(MultiplyNumbers(ref x, ref y));
            Console.WriteLine(x);

            // Tuples 
            // Tuples are lightweight objects
            var person = ("Ali", 20);
            Console.WriteLine(person.Item1);
            Console.WriteLine(person.Item2);

            (string name, int age) person2 = ("Aliaa", 19);
            Console.WriteLine(person2.Item1);
            Console.WriteLine(person2.name);

            int[] scores = new int[6];

            for (int i = 0; i < scores.Length; i++)
            {
                Console.Write($"Enter score {i + 1}: ");
                scores[i] = int.Parse(Console.ReadLine());

            }

            Console.WriteLine($"Average score: {GetAverage(scores):F2}");
            Console.WriteLine($"Highest score: {GetMax(scores)}");
            Console.WriteLine($"Scores above 70: {CountAbove(scores, 70)}");

            // String operations
            Console.Write("Enter a sentence: ");
            string sentence = Console.ReadLine();
            Console.WriteLine($"Number of characters: {sentence.Length}");
            Console.WriteLine($"Uppercase: {sentence.ToUpper()}");
            Console.WriteLine($"Lowercase: {sentence.ToLower()}");
            Console.Write("Enter a word to search for: ");
            string word = Console.ReadLine() ?? "";
            Console.WriteLine($"Word exists in sentence: {sentence.Contains(word)}");
            Console.WriteLine($"First character: {sentence[0]}");
            Console.WriteLine($"Last character: {sentence[sentence.Length - 1]}");
            Console.WriteLine($"Spaces replaced by '-': {sentence.Replace(' ', '-')}");
        }

        // Defining Methods 
        static int Add(int x, int y)
        {
            return x + y;
        }

        //Arrow form 
        static int Add2(int x, int y) => x + y;

        // Problem 1
        static double Area(double x, double y)
        {
            return x * y;
        }

        // Method overloading
        static double AddNumbers(double x, double y)
        {
            return x + y;
        }
        static int AddNumbers(int x, int y)
        {
            return x + y;
        }

        static void Greet(string Fname, string Lname)
        {
            Console.WriteLine($"Hello {Fname} {Lname}");
        }

        static void Greet(string name)
        {
            Console.WriteLine($"Hello {name}");
        }

        // Passing by reference
        static int MultiplyNumbers(ref int x, ref int y)
        {
            x = 20;
            return x * y;
        }

        // Using out
        // Passes by reference but used mainly for outputs

        static void OperateOnNumbers(int x, int y, out int sum, out int difference)
        {
            sum = x + y;
            difference = x - y;
        }

        // Arrays are passed by reference by default
        static int sumArray(int[] array)
        {
            int sum = 0;
            for (int i = 0; i < array.Length; i++)
            {
                sum += array[i];
            }
            return sum;
        }
        //Returing Arrays 
        static int[] OperateOnNumbers2(int x, int y)
        {
            int[] result = new int[2];
            result[0] = x + y;
            result[1] = x - y;
            return result;
        }

        // Returning tuples 

        static (int sum, int difference) OperateOnNumbers3(int x, int y)
        {
            return (x + y, x - y);
        }

        // Problem 3 
        static double GetAverage(int[] scores)
        {
            int sum = 0;
            foreach (int score in scores)
                sum += score;

            return (double)sum / scores.Length;
        }

        static int GetMax(int[] scores)
        {
            int max = scores[0];
            foreach (int score in scores)
                if (score > max)
                    max = score;

            return max;
        }

        static int CountAbove(int[] scores, int threshold)
        {
            int count = 0;
            foreach (int score in scores)
                if (score > threshold)
                    count++;

            return count;
        }

        // Recursion
        static int Factorial(int n)
        {
            if (n <= 1)
                return 1;
            return n * Factorial(n - 1);
        }

        // Problem 4
        static int SumArray(int[] numbers, int index)
        {
            if (index == numbers.Length)
                return 0;

            return numbers[index] + SumArray(numbers, index + 1);
        }


    }
}