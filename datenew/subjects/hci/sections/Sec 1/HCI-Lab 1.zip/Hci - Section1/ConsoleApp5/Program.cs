﻿using Microsoft.VisualBasic;

namespace ConsoleApp5
{
    internal class Program
    {
        static void Main(string[] args)
        {


            // Variable defination
            int x = 5;
            var y = "Hello"; // y type is string
            double z = 4.5;

            // Variable declaration
            int a;
            double b;
            // NOTE: you can't use var with declartions
            a = 10;

            // Printing
            Console.WriteLine("Hello world"); // new line printing the string
            Console.Write("Enter your name: "); // doesn't create a new line

            // Reading input
            string name = Console.ReadLine();    //Returns a string

            // Parsing input
            Console.Write("\nEnter your Age: ");
            int age = int.Parse(Console.ReadLine());
            // or 
            //int age = Convert.ToInt32(Console.ReadLine());

            // Problem 1 sol:
            Console.WriteLine("\nEnter your name:");
            string username = Console.ReadLine();
            Console.WriteLine("Enter your Age:");
            int userAge = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter your City:");
            string userCity = Console.ReadLine();
            Console.WriteLine($"Hello my name is {username}\nI am {userAge} years old\nI live in {userCity}");

            // Problem 2 sol:
            Console.WriteLine("Enter 2 numbers");
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            Console.WriteLine($"Sum: {num1 + num2}");
            Console.WriteLine($"Diff: {num1 - num2}");
            Console.WriteLine($"Multiplication: {num1 * num2}");
            Console.WriteLine($"Division: {num1 / num2}");
            Console.WriteLine($"Remainder: {num1 % num2}");

            // If statement 

            int grade = 75;
            if (grade > 85)
                Console.WriteLine("A");
            else if (grade > 75)
                Console.WriteLine("B");
            else if (grade > 65)
            {
                Console.WriteLine("C");
            }
            else
            {
                Console.WriteLine("FAIL");
            }
            // Switch (remember using break after each case is a must)
            switch (grade)
            {
                case > 85: { Console.WriteLine("A"); break; }
                case > 75: { Console.WriteLine("B"); break; }
                case > 65: { Console.WriteLine("C"); break; }
                case > 55: { Console.WriteLine("D"); break; }
                default: { Console.WriteLine("F"); break; }
            }

            // For loop
            for(int i = 0; i < 5; i++)
            {
                Console.WriteLine(i);
            }

            // WHILE
            int num = 1;
            int sum = 0;
            while(num > 0)
            {
                Console.WriteLine("Enter +ve numbers");
                num = int.Parse(Console.ReadLine());
                sum += num;
            }

            Console.WriteLine($"The sum is : {sum}");
            // DO while (used when you want the code to be executed atleast once)
            int MyNum;
            do
            {
                Console.WriteLine("Enter a positive number");
                 MyNum = int.Parse(Console.ReadLine());
                if (MyNum % 2 == 0)
                    Console.WriteLine("Even number");
                else
                {
                    Console.WriteLine("Odd number");

                }
            }
            while (MyNum > 0);


            // Array declaration and defination
            int[] arr = new int[3];
            int[] arr2 = { 1, 2, 3, 4, 5 };
            arr[1] = 10;

            foreach(int i in arr) // iterates on values not indicies 
            {
                Console.WriteLine(i);
            }

            // Problem 4
            int[] myArr = new int[5];
            for(int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Enter the number at index {i}");
                arr[i] = int.Parse(Console.ReadLine());
            }
            int sumArr = 0;
            int max = myArr[0];
            int min = myArr[0];
            int countEven = 0;
            for (int i = 0;i < 5; i++)
            {
                sumArr += myArr[i];
                if (myArr[i] > max)
                    max = myArr[i];

                if (myArr[i] < min)
                    min = myArr[i];

                if (myArr[i]%2==0)countEven++;
            }

            Console.WriteLine($"Sum {sumArr}");
            Console.WriteLine($"Average {(double)sumArr / myArr.Length}");
            Console.WriteLine($"Max {max}");
            Console.WriteLine($"Min {min}");
            Console.WriteLine($"CountEven {countEven}");


        }
    }
}

