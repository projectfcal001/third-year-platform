﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp16
{

    // Ho wto define a struct
    public struct Point
    {
        public int x;
        public int y;

        // Structs can have constructors as well
        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        // Structs can also have methods
        public override string ToString()
        {
            return $"X: {x}, Y :{y}\n";
        }
    }
}
