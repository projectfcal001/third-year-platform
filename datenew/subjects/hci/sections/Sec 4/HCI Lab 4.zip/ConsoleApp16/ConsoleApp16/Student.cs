﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp16
{
    internal class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double GPA { get; set; }

        public Student(int id, string name, double GPA)
        {
            Id = id;
            Name = name;
            this. GPA = GPA;    
        }

        public override string ToString()
        {
            return $"ID: {Id}, Name: {Name}, GPA: {GPA}";
        }
    }
}
