﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp16
{
    // defining abstract classes
    // an abstract class cannot be instantiated 
    abstract class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }

        // an abstract class can have a constructor 
        // mainly to be used from children classes

        public Person(int id, string name, string department)
        {
            Id = id;
            Name = name;
            Department = department;
        }

        // abstract classes can have methods as well
        // Methods can be abstract or non abstract

        public void printPerson() // non abstract method
        {
            Console.WriteLine($"ID {Id}, Name: {Name}, Department : {Department}");
        }

        // abstract methods
        // an abstract method doesn't have a body
        // classes that inherit must have their own implemntation for the method
        public abstract void printPerson2();
    }

    class Employee : Person
    {
        public double Salary { get; set; }

        public Employee(int Id, string Name, string department, double salary)
            : base(Id, Name, department) // calling the constructor of the abstract class
        {
            Salary = salary;
        }

        // Must be implemented and must use the keyword override
        public  override void printPerson2()
        {
            Console.WriteLine($"ID {Id}, Name: {Name}, Department : {Department}, Salary: {Salary}");
        }
    }
}
