﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp16
{

    // Interfaces are mostly used to implement common behaviours (Methods and functions)
    // Two classes might not have common properties but they both implement the same methods 
    // a class can implement many interfaces but only inherit from one other class at the same time
    public interface IDisctountable
    {
        //Methods in interfaces can have a default implemntation or not

        //No default implementation
        public double getDiscountedPrice();

        public void printPrice()
        {
            Console.WriteLine("NOT Implemented");
        }
    }
    internal class Book : IDisctountable
    {
        public string Title { get; set; }
        public double Price { get; set; }

        public Book(string t, double p)
        {
            Title = t;
            Price = p;
        }
        public double getDiscountedPrice()
        {
            return Price*0.90;
        }
    }

    internal class Laptop : IDisctountable
    {
        public string Model { get; set; }
        public double Price { get; set; }

        public Laptop(string m, double p)
        {
            Model = m;
            Price = p;
        }
        public double getDiscountedPrice()
        {
            return Price * 0.85;
        }
    }
}
