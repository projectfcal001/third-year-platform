﻿namespace ConsoleApp16
{
    internal class Program
    {
        // Delegates
        // A delegate is a pointer to a method that has  specific return and parameter types
        public delegate int OperateOnNumbers(int x, int y); // this can point to any method that returns an integar and accepts 2 parameters (int, int)

        public static bool isEven(int x)
        {
            return x % 2 == 0;
        }
        public static int GetSum(int x, int y)
        {
            Console.WriteLine(x + y);
            return x + y;
        }

        public static int GetDiff(int x, int y)
        {
            Console.WriteLine(x - y);
            return x - y;
        }

        public static int GetMultiplcationResult(int x, int y)
        {
            Console.WriteLine(x * y);
            return x * y;
        }
        static void Main(string[] args)
        {



            int x = 10;
            int y = 20;
            OperateOnNumbers op = GetSum;
            op(x, y);

            op = GetDiff;
            op(x, y);

            op = GetMultiplcationResult;
            op(x, y);

            // Delegates can be multicast = points to more than one function 
            op = GetSum;
            op += GetDiff;
            op += GetMultiplcationResult;

            op(3, 4);

            // Predicates
            // Special delegates that take one parameter and always return a boolean

            Predicate<int> p = isEven;
            Console.WriteLine(p(5));
            Console.WriteLine(p(4));

            //Struct instance
            Point p1 = new Point(5, 6);

            // Structs are value types not reference types
            // This actually copies the data in p1 and allocates a new place in memory for p2
            Point p2 = p1;

            p2.x = 10;
            p2.y = 20;
            Console.Write(p1);
            Console.Write(p2);

            // an array or list can be of an interface type
            IDisctountable[] disctountables = new IDisctountable[2];
            disctountables[0] = new Laptop("dell", 20000);
            disctountables[1] = new Book("C# fundmentals", 500);

            foreach (var d in disctountables)
            {
                Console.WriteLine(d.getDiscountedPrice());
                d.printPrice(); // Uses default implemntation
            }

            // Lists 
            // Dynamically sized arrays

            List<int> ints = new List<int>();

            // to add elements
            ints.Add(10);
            ints.Add(10);
            ints.Add(10);
            ints.Add(10);
            ints.Add(20);
            ints.Add(30);
            ints.Add(40);

            // Accessible by index as well
            ints[1] = 100;

            ints.Remove(10);// removes first occurrence of 10

            ints.Sort();  // Sorts in place no new array

            foreach (int i in ints)
            {
                Console.Write($"{i}, ");
            }
            Console.WriteLine();
            Console.WriteLine(ints.Contains(20));// returns true or false
            Console.WriteLine(ints.Count); // number of elements

            // Dictionaries
            // Stores key-value pairs
            Dictionary<string, string> dict = new Dictionary<string, string>();
            // adding keys
            dict["Name"] = "Ali";
            dict["City"] = "Assiut";

            Console.WriteLine(dict.ContainsKey("ID")); // returns true or false

            string? n = dict.GetValueOrDefault("Name");// returns null if key isn't found

            string name = "";
            if (dict.TryGetValue("Name", out name))
            {
                Console.WriteLine(name);
            }

            // Iterating over a dictionary
            foreach (var item in dict)
            {
                Console.WriteLine($"{item.Key}:{item.Value}");
            }

            List<Student> students = new List<Student>();
            students.Add(new Student(1, "Ahmed", 3.12));
            students.Add(new Student(2, "Ali", 3.6));
            students.Add(new Student(3, "Salma", 3.9));
            students.Add(new Student(4, "Mahmoud", 3.2));
            students.Add(new Student(5, "Nagham", 4.0));
            students.Add(new Student(6, "Amany", 3.5));
            students.Add(new Student(7, "Dalia", 2.7));

            // LINQ (language intergated query)

            //Where
            var stds = students.Where(s => s.GPA > 3.5);

            students.Add(new Student(8, "Omar", 3.9)); // Omar will appear in query results
            // LINQ queries are lazy, they only execute when result is needed

            foreach (var student in stds)
            { // executions happens here
                Console.WriteLine(student);
            }

            // SELECT
            var names = students.Select(s => s.Name);
            foreach (var student in names)
            {
                Console.WriteLine(student);
            }

            // Orderby and OrderByDescending
            stds = students.OrderByDescending(s => s.GPA);
            foreach (var student in stds)
            {
                Console.WriteLine(student);
            }

            // To overcome lazy execution if needed, add toList()

            stds = students.Where(s => s.GPA > 3.5).ToList();
            students.Add(new Student(9, "Abdelrahman", 3.9));
            Console.WriteLine();
            foreach (var student in stds)
            {
                Console.WriteLine(student);
            }

            int c = students.Count(s => s.GPA > 3);
            Console.WriteLine(c);

            double sum = students.Sum(s => s.GPA);
            Console.WriteLine(sum);

            double avg = students.Average(s => s.GPA);
            Console.WriteLine(avg);

            double max = students.Max(s => s.GPA);
            Console.WriteLine(max);

            double min = students.Min(s => s.GPA);
            Console.WriteLine(min);


            Student? top = students.OrderByDescending(s => s.GPA).FirstOrDefault();
            Console.WriteLine(top);

            // Try Parse
            int t;
            if (int.TryParse(Console.ReadLine(), out t))
            {
                Console.WriteLine(t);
            }
        }

    }
}
